<?php
include_once "./conn.php";
// include "./cookieToS.php";
$accountSql = "SELECT id,name FROM `order_accounts`";
// $accountData = mysqli_query($conn,$accountSql);
$accountData = $conn->query($accountSql);
$accountData->fetch_all(MYSQLI_ASSOC);
$cardSql = "SELECT id,card_no FROM `order_card`";
$cardsData =  mysqli_query($conn, $cardSql);
include_once "header.php";

?>
<div class="container ">
    <!-- <div class="row">
            <div class="col-8">
                <a href="data.php" class="btn btn-primary" onclick="window.history.back()">View Data</a>
                
            </div>
            <div class="col-4"><a href="logout.php" class="btn btn-primary"><i class="fa fa-signout"></i>Sign Out</a></div>
        </div> -->
</div>
<div class="container mt-2">
    <h2 class="text-center"><a href="../index.php">Order Transaction</a></h2>


    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <?php
            // is_null($var1) ? print_r("True\n") : print_r("False\n")
            if (isset($_GET['id'])) {
                $id = $_GET['id'];
                $sql = "SELECT * FROM order_list WHERE id = '$id' AND status != 1";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    $data = mysqli_fetch_array($result);
                    // echo print_r($data);

                } else {
                    echo "Don't be oversmart (sql)";
                    die();
                }
            }

            ?>
            <form action="process.php" method="post" enctype="multipart/form-data">

                <!-- 2 column grid layout with text inputs for the first and last names -->
                <div class="row mb-1">
                    <div class="col">
                        <div class="form-outline">
                            <label class="form-label" for="firm_name">Item Name<sup class="text-danger">*</sup> </label>
                            <input type="text" id="item_name" class="form-control" name="item_name" value="<?= isset($data['item_name']) ? $data['item_name'] : ''; ?>" required />
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <label class="form-label" for="serial_no">Serial No.<sup class="text-danger">*</sup> </label>
                            <input type="text" id="serial_no" class="form-control" name="serial_no" value="<?= isset($data['serial_no']) ? $data['serial_no'] : ''; ?>" required />
                        </div>
                    </div>
                </div>
                <!-- 2 column grid layout with text inputs for the first and last names -->
                <div class="row mb-1">
                    <div class="col">
                        <div class="form-outline">
                            <label class="form-label" for="platform">Platform<sup class="text-danger">*</sup> </label>
                            <!-- <input type="text" id="platform" class="form-control" name="platform" value="<?= isset($data['platform']) ? $data['platform'] : ''; ?>" required /> -->
                            <select id="platform" class="form-control" name="platform">
                                <option value="1">pinelab</option>
                                <option value="2">Kotak</option>
                            </select>


                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <label class="form-label" for="account_id">Account ID<sup class="text-danger">*</sup> </label>
                            <!-- <input type="text" id="account_id" class="form-control" name="account_id" value="<?= isset($data['account_id']) ? $data['account_id'] : ''; ?>" required /> -->
                            <select id="account_id" class="form-control" name="account_id">
                                <?php
                                foreach ($accountData as $row) {
                                ?>
                                    <option value="<?= $row['id'] ?>"><?= $row['name'] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
                <!-- 2 column grid layout with text inputs for the first and last names -->
                <div class="row mb-1">

                    <div class="col">
                        <div class="form-outline">
                            <label class="form-label" for="price">Price<sup class="text-danger">*</sup> </label>
                            <input type="text" id="price" class="form-control" name="price" value="<?= isset($data['price']) ? $data['price'] : ''; ?>" required />
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <label class="form-label" for="card_id">Card Id<sup class="text-danger">*</sup> </label>
                            <select id="card_id" class="form-control" name="card_id">
                                <?php
                                foreach ($cardsData as $row) {
                                ?>
                                    <option value="<?= $row['id'] ?>"><?= $row['card_no'] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- 2 column grid layout with text inputs for the first and last names -->
                <div class="row mb-1">
                    <div class="col">
                        <div class="form-outline">
                            <label class="form-label" for="status">Status<sup class="text-danger">*</sup> </label>

                            <!-- <input type="text" id="status" class="form-control" name="status" value="<?= isset($data['status']) ? $data['status'] : ''; ?>" required /> -->

                            <select id="status" class="form-control" name="status">
                                <option value="1">Success</option>
                                <option value="2">Cancel</option>
                                <option value="3">Deliver</option>
                                <option value="4">Error</option>
                            </select>


                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <label class="form-label" for="date">Date<sup class="text-danger">*</sup> </label>
                            <input type="date" id="date" class="form-control" name="date" value="<?= isset($data['date']) ? $data['date'] : ''; ?>" required />
                        </div>
                    </div>
                </div>


                <!-- Message input -->
                <div class="form-outline mb-4">
                    <label class="form-label" for="form6Example7">Remark</label>
                    <textarea class="form-control" id="form6Example7" rows="2" name="remark"><?= isset($data['remark']) ? $data['remark'] : ''; ?></textarea>
                </div>


                <!--update button condition-->
                <?php if (isset($_GET['id'])) { ?>
                    <button type="submit" name="update" class="btn btn-primary btn-block mb-4 w-100">
                        Update
                    </button>
                <?php } else { ?>
                    <!-- Submit button -->
                    <button type="submit" name="register" class="btn btn-primary btn-block mb-4 w-100">
                        Submit
                    </button>
                <?php } ?>



                <?php if (isset($_GET['msg'])) {
                ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Inserted</strong> <?= $_GET['msg'] ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php } ?>
            </form>

        </div>
    </div>

</div>





<script>
    $(document).ready(function() {
        $("select").selectize({
            sortField: "text",
        });
        setTimeout(() => {
            $(".alert").slideUp()
        }, 4000);
    });
</script>
</body>

</html>