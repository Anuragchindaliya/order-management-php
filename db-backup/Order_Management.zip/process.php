<?php
include "./conn.php";
if (isset($_POST['register'])) {
    $fields_str = "";
    $values_str = "";
    foreach ($_POST as $key => $val) {
        if ($key == "register") {
            continue;
        }
        $fields_str = $fields_str . ", `" . $key . "`";
        $values_str = $values_str . ", '" . $val . "'";
    }
    echo count($_POST);
    $fields_str =  ltrim($fields_str, ",");
    $values_str =  ltrim($values_str, ",");
    $sql = "INSERT INTO `order_list`($fields_str) VALUES ($values_str)";
    echo $sql;
    if (mysqli_query($conn, $sql)) {
        echo "data inserted";
    } else {
        echo "data is not inserted";
    }
}
if (isset($_POST['addUserAccount'])) {
    extract($_POST);
    $sql = "INSERT INTO `order_accounts`( `name`, `mob`, `email`, `remark`) VALUES ('$name','$mob','$email','$remark')";
    if (mysqli_query($conn, $sql)) {
        echo "data is inserted";
    } else {
        echo "errpr";
    }
}
if (isset($_POST['addCard'])) {
    extract($_POST);
    $sql = "INSERT INTO `order_card`( `card_name`, `card_no`, `mob`, `remark`) VALUES ('$card_name','$card_no','$mob','$remark')";
    if (mysqli_query($conn, $sql)) {
        echo "data is inserted";
    } else {
        echo "error";
    }
}
